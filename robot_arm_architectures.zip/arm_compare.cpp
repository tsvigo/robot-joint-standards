// C++17. Parametric 2-DOF planar model of ONE robot arm.
// IMPORTANT: M2 planar screening ONLY, NOT a verified dynamic model of the 7-DOF arm.
// All actuator and balancing masses and 0.48-m upper arm length are HYPOTHESES.
// Source stored masses from Stage2V audit: L=5.999, R=7.531 kg (unvalidated placeholders).
// Shoulder-to-palm distances from Stage1: L=0.974, R=1.003 m.
// Elbow+wrist motor locations for A: at elbow and wrist; B: moved to shoulder.
// C uses A layout plus gravity compensation for its OWN empty-arm gravity only.
// Dynamic gravity and acceleration torques omit rotor-reflected inertia, friction,
// elasticity, Coriolis, backlash, payload distribution, safety factors and contact.
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
using namespace std;
constexpr double g = 9.81, pi = 3.141592653589793;
struct Input {
  string side;
  double L1,L2,m1,m2,mh;
};
struct Spec {
  string arch;
  double m_shoulder, m_elbow, m_wrist;
  double m_pulley_elbow, m_pulley_wrist, m_cable_upper, m_cable_fore;
  double m_balance_sh, m_balance_el, k_sh, k_el;
};
struct Result {
  double Tg_sh, Tg_el, Td_sh, Td_el, T_sh, T_el, M11, M12, M22, M_total;
  double Tload_sh,Tload_el, Tself_sh,Tself_el, Tcomp_sh,Tcomp_el;
};

// This is a simplified 2-link planar arm. q1 is angle of upper arm from
// horizontal; q2 is relative elbow angle; q1=q2=0 means fully extended horizontal.
Result evaluate(Input in, Spec s, double payload, double q1deg, double q2deg,
                double ddq_sh, double ddq_el) {
  double L=in.L1, l=in.L2, q1=q1deg*pi/180, q2=q2deg*pi/180;
  double c1=cos(q1), c12=cos(q1+q2), c2=cos(q2);
  double sh=0,el=0, M11=0,M12=0,M22=0;
  auto rod_upper=[&](double m){
    sh+=m*g*L/2*c1;
    M11+=m*L*L/3;
  };
  auto point_upper=[&](double m,double r){
    sh+=m*g*r*c1;
    M11+=m*r*r;
  };
  auto rod_fore=[&](double m){
    sh+=m*g*(L*c1+l/2*c12); el+=m*g*l/2*c12;
    M11+=m*(L*L+L*l*c2+l*l/3);
    M12+=m*(L*l/2*c2+l*l/3);
    M22+=m*l*l/3;
  };
  auto point_fore=[&](double m,double r){
    sh+=m*g*(L*c1+r*c12); el+=m*g*r*c12;
    M11+=m*(L*L+r*r+2*L*r*c2);
    M12+=m*(r*r+L*r*c2);
    M22+=m*r*r;
  };
  rod_upper(in.m1); rod_fore(in.m2); point_fore(in.mh,l);
  // A: elbow & wrist motors on links. B: both remote at shoulder.
  point_upper(s.m_elbow, L);
  point_fore(s.m_wrist, l);
  point_upper(s.m_pulley_elbow,L);
  point_fore(s.m_pulley_wrist,l);
  rod_upper(s.m_cable_upper);
  rod_fore(s.m_cable_fore);
  // C compensator hardware: mass at 0.1 m and at elbow pivot, no actual spring torque yet
  point_upper(s.m_balance_sh,0.10);
  point_upper(s.m_balance_el,L);
  double sh_no_load=sh,el_no_load=el;
  point_fore(payload,l);
  double tload_sh=sh-sh_no_load, tload_el=el-el_no_load;
  // Calibration of the spring mechanism assumes k% of A's empty-arm torque,
  // NOT k% of patient/payload torque; this is an ideal target torque profile.
  // To ensure apples-to-apples, remove own balance-hardware weight from target.
  double balance_hw_sh=g*c1*(s.m_balance_sh*0.10+s.m_balance_el*L);
  double comp_sh=s.k_sh*(sh_no_load-balance_hw_sh);
  double comp_el=s.k_el*el_no_load;
  double tg_sh=sh-comp_sh, tg_el=el-comp_el;
  double td_sh=M11*ddq_sh+M12*ddq_el;
  double td_el=M12*ddq_sh+M22*ddq_el;
  double total=in.m1+in.m2+in.mh+s.m_shoulder+s.m_elbow+s.m_wrist+
               s.m_pulley_elbow+s.m_pulley_wrist+s.m_cable_upper+s.m_cable_fore+
               s.m_balance_sh+s.m_balance_el;
  return {tg_sh,tg_el,td_sh,td_el,tg_sh+td_sh,tg_el+td_el,
          M11,M12,M22,total,tload_sh,tload_el,sh_no_load,el_no_load,comp_sh,comp_el};
}
int main(int argc, char**argv){
  string out=argc>1?argv[1]:"results.csv";
  // Inputs correspond to Stage2V left/right total masses with residual hand mass.
  // Geometry L1=0.48m is HYPOTHETICAL; L1+L2 matches Stage1 shoulder-to-palm.
  vector<Input> arms={{"left",.480,.494,2.723,2.723,5.999-5.446},
                      {"right",.480,.523,3.361,3.361,7.531-6.722}};
  // All actuator masses, hardware, compensation factors are speculative scenarios.
  vector<Spec> specs={
    {"A_local",22,12,4,0,0,0,0,0,0,0,0},
    {"B_remote",22+12+4,0,0,1.5,.8,1,1,0,0,0,0},
    {"C_local_balance",22,12,4,0,0,0,0,4,2,.7,.7},
    {"D_remote_balance",22+12+4,0,0,1.5,.8,1,1,4,2,.7,.7}
  };
  vector<double> payloads={0,10,50,100};
  vector<pair<double,double>> poses={{0,0},{-21,45},{-25,60},{-45,90}};
  ofstream f(out);
  if(!f){cerr<<"Cannot open file: "<<out<<"\n";return 1;}
  f<<fixed<<setprecision(5);
  f<<"side,arch,payload_kg,q_sh_deg,q_el_deg,ddq_sh_rad_s2,ddq_el_rad_s2,"
      "total_arm_kg,Tg_sh_Nm,Tg_el_Nm,Tdyn_sh_Nm,Tdyn_el_Nm,Ttotal_sh_Nm,Ttotal_el_Nm,"
      "M11_kg_m2,M12_kg_m2,M22_kg_m2,Tload_sh_Nm,Tload_el_Nm,"
      "Tself_sh_Nm,Tself_el_Nm,Tcomp_sh_Nm,Tcomp_el_Nm\n";
  int rows=0;
  for(const auto& arm:arms)for(const auto& s:specs)
  for(double p:payloads)for(auto [q1,q2]:poses)
  for(auto [a1,a2]:vector<pair<double,double>>{{0,0},{1,0},{0,1},{1,1}}){
    auto r=evaluate(arm,s,p,q1,q2,a1,a2);
    f<<arm.side<<","<<s.arch<<","<<p<<","<<q1<<","<<q2<<","<<a1<<","<<a2<<","<<r.M_total<<","<<r.Tg_sh<<","<<r.Tg_el<<","<<r.Td_sh<<","<<r.Td_el<<","<<r.T_sh<<","<<r.T_el<<","<<r.M11<<","<<r.M12<<","<<r.M22<<","<<r.Tload_sh<<","<<r.Tload_el<<","<<r.Tself_sh<<","<<r.Tself_el<<","<<r.Tcomp_sh<<","<<r.Tcomp_el<<"\n";
    ++rows;
  }
  f.close();
  cout<<"saved "<<out<<": "<<rows<<" rows\n";
  cout<<setprecision(3)<<fixed;
  for(auto &arm:arms){
    cout<<"\n"<<arm.side<<" (L1="<<arm.L1<<" L2="<<arm.L2<<")\n";
    for(const auto&s:specs){
      auto e=evaluate(arm,s,0,0,0,0,0);
      auto v=evaluate(arm,s,100,0,0,1,0);
      cout<<setw(18)<<s.arch<<" mass="<<e.M_total<<" Tg_sh(empty)="<<e.Tg_sh
          <<" Tg_el(empty)="<<e.Tg_el<<" Tg_sh(100kg)="<<v.Tg_sh
          <<" J11(100kg)="<<v.M11<<" T_sh(100kg,1rad/s²)="<<v.T_sh<<"\n";
    }
  }
}
